package com.calldetails.model;

//import java.time.LocalTime;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class CallDetails {
	@Id
	Integer callid;
	
	Integer fcallerid;
	Integer tcallerid;
	String cdate;
	String callstart;
	String callend;
	Integer totalduration;
	
	CallDetails(){
		
	}
	public CallDetails(Integer callid, Integer fcallerid, Integer tcallerid, String cdate, String callstart,
			String callend, Integer totalduration) {
		super();
		this.callid = callid;
		this.fcallerid = fcallerid;
		this.tcallerid = tcallerid;
		this.cdate = cdate;
		this.callstart = callstart;
		this.callend = callend;
		this.totalduration = totalduration;
	}

	public Integer getCallid() {
		return callid;
	}

	public void setCallid(Integer callid) {
		this.callid = callid;
	}

	public Integer getFcallerid() {
		return fcallerid;
	}

	public void setFcallerid(Integer fcallerid) {
		this.fcallerid = fcallerid;
	}

	public Integer getTcallerid() {
		return tcallerid;
	}

	public void setTcallerid(Integer tcallerid) {
		this.tcallerid = tcallerid;
	}

	public String getCdate() {
		return cdate;
	}

	public void setCdate(String cdate) {
		this.cdate = cdate;
	}

	public String getCallstart() {
		return callstart;
	}

	public void setCallstart(String callstart) {
		this.callstart = callstart;
	}

	public String getCallend() {
		return callend;
	}

	public void setCallend(String callend) {
		this.callend = callend;
	}

	public Integer getTotalduration() {
		return totalduration;
	}

	public void setTotalduration(Integer totalduration) {
		this.totalduration = totalduration;
	}
	@Override
	public String toString() {
		return "CallDetails [callid=" + callid + ", fcallerid=" + fcallerid + ", tcallerid=" + tcallerid + ", cdate="
				+ cdate + ", callstart=" + callstart + ", callend=" + callend + ", totalduration=" + totalduration
				+ "]";
	}
	
	

	
	

}