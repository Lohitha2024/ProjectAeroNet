package com.example.ProjectAeroNet;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjectAeroNetApplicationTests {

	@Test
	void contextLoads() {
	}

}
