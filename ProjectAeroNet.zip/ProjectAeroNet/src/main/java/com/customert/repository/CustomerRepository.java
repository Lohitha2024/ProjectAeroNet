package com.customert.repository;

public class CustomerRepository {

}
