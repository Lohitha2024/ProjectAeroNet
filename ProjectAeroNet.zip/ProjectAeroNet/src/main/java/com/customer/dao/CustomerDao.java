package com.customer.dao;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import com.customer.model.Customer;


@Repository

public interface CustomerDao extends JpaRepository<Customer,Integer> {
	
	List<Customer> findAllByCname(String cname);
	List<Customer> findAllByAddress(String address);
	
	
}

