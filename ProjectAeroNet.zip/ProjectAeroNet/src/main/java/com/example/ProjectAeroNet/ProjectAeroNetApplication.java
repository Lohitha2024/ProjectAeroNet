package com.example.ProjectAeroNet;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjectAeroNetApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjectAeroNetApplication.class, args);
	}

}
